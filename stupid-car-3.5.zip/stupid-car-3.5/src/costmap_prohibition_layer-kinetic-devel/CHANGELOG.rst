^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package costmap_prohibition_layer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.5 (2017-01-25)
------------------
* Support a rolling window map
  Enable support for rolling window maps

0.0.4 (2016-10-30)
------------------
* Enable recognizing Integer values in single points
* restored deleted line

0.0.3 (2016-10-28)
------------------
* Install scripts added

0.0.2 (2016-10-27)
------------------
* Initial package version
